package com.randomizer.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final SecureRandom random = new SecureRandom();
    private final List<Integer> history = new ArrayList<>();
    private TextView resultView;
    private TextView historyView;
    private EditText minInput;
    private EditText maxInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(56), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(247, 248, 252));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -1));

        TextView title = new TextView(this);
        title.setText("🎲 Randomizer");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(25, 28, 36));
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, -2, 0, 0, 0, 20));

        TextView subtitle = new TextView(this);
        subtitle.setText("Выбери диапазон и получи случайное число");
        subtitle.setTextSize(16);
        subtitle.setTextColor(Color.rgb(95, 100, 115));
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, lp(-1, -2, 0, 0, 0, 28));

        LinearLayout rangeRow = new LinearLayout(this);
        rangeRow.setOrientation(LinearLayout.HORIZONTAL);
        rangeRow.setGravity(Gravity.CENTER);
        root.addView(rangeRow, lp(-1, -2, 0, 0, 0, 20));

        minInput = numberInput("1");
        maxInput = numberInput("100");
        rangeRow.addView(minInput, new LinearLayout.LayoutParams(0, dp(58), 1));

        TextView dash = new TextView(this);
        dash.setText("  —  ");
        dash.setTextSize(20);
        dash.setGravity(Gravity.CENTER);
        rangeRow.addView(dash, new LinearLayout.LayoutParams(-2, dp(58)));

        rangeRow.addView(maxInput, new LinearLayout.LayoutParams(0, dp(58), 1));

        resultView = new TextView(this);
        resultView.setText("?");
        resultView.setTextSize(64);
        resultView.setGravity(Gravity.CENTER);
        resultView.setTextColor(Color.rgb(76, 79, 220));
        resultView.setBackgroundColor(Color.WHITE);
        resultView.setPadding(dp(12), dp(24), dp(12), dp(24));
        root.addView(resultView, lp(-1, -2, 0, 0, 0, 20));

        Button generate = new Button(this);
        generate.setText("СГЕНЕРИРОВАТЬ");
        generate.setTextSize(17);
        generate.setAllCaps(false);
        generate.setOnClickListener(v -> generateNumber());
        root.addView(generate, lp(-1, dp(58), 0, 0, 0, 18));

        Button clear = new Button(this);
        clear.setText("Очистить историю");
        clear.setAllCaps(false);
        clear.setOnClickListener(v -> {
            history.clear();
            resultView.setText("?");
            updateHistory();
        });
        root.addView(clear, lp(-1, dp(52), 0, 0, 0, 24));

        TextView historyTitle = new TextView(this);
        historyTitle.setText("Последние результаты");
        historyTitle.setTextSize(18);
        historyTitle.setTextColor(Color.rgb(25, 28, 36));
        root.addView(historyTitle, lp(-1, -2, 0, 0, 0, 8));

        historyView = new TextView(this);
        historyView.setText("Пока пусто");
        historyView.setTextSize(16);
        historyView.setTextColor(Color.rgb(95, 100, 115));
        historyView.setLineSpacing(0, 1.25f);
        root.addView(historyView, lp(-1, -2, 0, 0, 0, 0));

        setContentView(scroll);
    }

    private EditText numberInput(String value) {
        EditText input = new EditText(this);
        input.setText(value);
        input.setTextSize(18);
        input.setGravity(Gravity.CENTER);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setBackgroundColor(Color.WHITE);
        input.setPadding(dp(8), 0, dp(8), 0);
        return input;
    }

    private void generateNumber() {
        try {
            long minLong = Long.parseLong(minInput.getText().toString().trim());
            long maxLong = Long.parseLong(maxInput.getText().toString().trim());
            if (minLong < Integer.MIN_VALUE || maxLong > Integer.MAX_VALUE) {
                throw new NumberFormatException();
            }
            int min = (int) minLong;
            int max = (int) maxLong;
            if (min > max) {
                int t = min; min = max; max = t;
            }
            long bound = (long) max - min + 1L;
            int value = (int) (min + random.nextLong(bound));
            resultView.setText(String.valueOf(value));
            history.add(0, value);
            while (history.size() > 10) history.remove(history.size() - 1);
            updateHistory();
        } catch (Exception e) {
            Toast.makeText(this, "Введите корректный диапазон", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateHistory() {
        if (history.isEmpty()) {
            historyView.setText("Пока пусто");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < history.size(); i++) {
            if (i > 0) sb.append("   •   ");
            sb.append(history.get(i));
        }
        historyView.setText(sb.toString());
    }

    private LinearLayout.LayoutParams lp(int w, int h, int ml, int mt, int mr, int mb) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(ml), dp(mt), dp(mr), dp(mb));
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
