# Randomizer Android App

Простое Android-приложение на Java без сетевых разрешений.

## Возможности
- Случайное целое число в выбранном диапазоне
- История последних 10 результатов
- Очистка истории
- Android 6.0+ (minSdk 23)

## Сборка
Требуется Android SDK 35, JDK 17 и Gradle 8.x.

```bash
gradle assembleDebug
```

APK появится в:
`app/build/outputs/apk/debug/app-debug.apk`
